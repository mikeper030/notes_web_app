const recordAudio = () =>
  new Promise(async resolve => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    const audioChunks = [];

    mediaRecorder.addEventListener("dataavailable", event => {
      audioChunks.push(event.data);
    });

    const start = () => mediaRecorder.start();

    const stop = () =>
      new Promise(resolve => {
        mediaRecorder.addEventListener("stop", () => {
          audioBlob = new Blob(audioChunks);
          const audioUrl = URL.createObjectURL(audioBlob);
          const audio = new Audio(audioUrl);
          const play = () => audio.play();
          resolve({ audioBlob, audioUrl, play });
        });

        mediaRecorder.stop();
      });

    resolve({ start, stop });
  });

const sleep = time => new Promise(resolve => setTimeout(resolve, time));

const handleAction = async () => {
    
    var playing=false;
  const recorder = await recordAudio();
  const recordButton = document.getElementById('record_start');
    const stopButton = document.getElementById('record_stop');
  const playButton = document.getElementById('record_play');
   stopButton.disabled=false;
   recordButton.disabled = true;
  var startTime = Date.now();
 
  var interval = setInterval(function() {
     elapsedTime = Date.now() - startTime;
   
   }, 100);
  recorder.start();
  $('#record_start').css("background","red")
  
  //start recording
  
  stopButton.onclick = async function(){
      recordButton.disabled = false;
         stopButton.disabled=true;
         playButton.disabled=false;
           $('#record_start').css("background","#00b8d4")

          audio = await recorder.stop();
          duration=elapsedTime;
          interval="undefined";
          
  };
  playButton.onclick = async function(){
      if(!playing){
           audio.play();
            playing=true;
            $('#record_play_icon').replaceWith('<i class="far fa-pause-circle" id="record_play_icon" style="color:white;"></i>')
           
      }else{
          $('#record_play_icon').replaceWith('<i class="far fa-play-circle" id="record_play_icon" style="color:white;"></i>')
           //audio.stop();
           console.log(audio);
           playing=false;

      }
      
  };
  
  
 
 
  
  
}