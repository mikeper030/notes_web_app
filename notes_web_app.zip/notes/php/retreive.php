<?
$file=$_POST['file'];
$uid=$_POST['uid'];
$filename = "ftp://admin@ultimatesoft-il.com:mikepe0301@ftp.ultimatesoft-il.com/htdocs/user_data/".$uid."/".$file;
header('Content-Type: image/jpeg');


 
 echo  base64_encode(file_get_contents($filename));



?>