<?php

 $ftp_server="ftp.ultimatesoft-il.com";
 $ftp_user_name="admin@ultimatesoft-il.com";
 $ftp_user_pass="mikepe0301";
 
 
 $remote_file_name = $_POST['name'];

$uid= $_POST['uid'];
$file =$_POST['file'];
 
 // set up basic connection
 $conn_id = ftp_connect($ftp_server);

 // login with username and password
 $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
 $ftp_path = 'user_data/'.$uid.'/'.$remote_file_name;
 
 // upload a file
$data = str_replace('data:image/png;base64,', '', $file);
$data = base64_decode( str_replace(' ', '+', $data) );
  ftp_chdir($conn_id, "user_data");
   ftp_chdir($conn_id, $uid);
  
 if (file_put_contents("ftp://admin@ultimatesoft-il.com:mikepe0301@ftp.ultimatesoft-il.com/htdocs/user_data/".$uid."/".$remote_file_name, $data)) {
    echo "success";
    exit;
 } else {
    
    echo "fail";
    exit;
    }
 // close the connection
 ftp_close($conn_id);


?> 