<?php
 if ( 0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
   }
   else {
       
 $ftp_server="ftp.ultimatesoft-il.com";
 $ftp_user_name="admin@ultimatesoft-il.com";
 $ftp_user_pass="mikepe0301";
 
 $uid= $_POST['uid'];
 $file =$_FILES['file']['tmp_name'];
 $remote_file_name = $_POST['name'];

 // set up basic connection
 $conn_id = ftp_connect($ftp_server);

 // login with username and password
 $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
 $ftp_path = 'htdocs/user_data/'.$uid.'/'.$remote_file_name;
 // upload a file
 if (ftp_put($conn_id, $ftp_path, $file, FTP_BINARY)) {
    echo "success";
    exit;
 } else {
    
    echo "fail";
    exit;
    }
 // close the connection
 ftp_close($conn_id);
}

?> 