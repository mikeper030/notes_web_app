<?php


$remote_file_name=$_POST['file'];
$uid=$_POST['uid'];
// server credentials
$ftp_server = "ftp.ultimatesoft-il.com";
$ftp_username = "admin@ultimatesoft-il.com";
$ftp_userpass = "mikepe0301";

// set up basic connection
$conn_id = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");

// login with username and password
ftp_login($conn_id, $ftp_username, $ftp_userpass);

ftp_pasv($conn_id, true);

//change dir


// try to delete $file
$file ="htdocs/user_data/".$uid.'/'.$remote_file_name;


if (ftp_delete($conn_id, $file)) {
echo "deleted";
} else {
  echo("error");
}

// close the connection
ftp_close($conn_id);


?>