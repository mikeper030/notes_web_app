<?php



// define some variables
$local_file = $_GET['file'];
$uid=$_GET['uid'];
$server_file = "/htdocs/user_data/".$uid."/".$local_file;
$ftp_server="ftp.ultimatesoft-il.com";
$ftp_user_name="admin@ultimatesoft-il.com";
$ftp_user_pass="mikepe0301";

//$conn_id = ftp_connect($ftp_server);
$filename = "ftp://admin@ultimatesoft-il.com:mikepe0301@ftp.ultimatesoft-il.com/htdocs/user_data/".$uid."/".$local_file;
// login with username and password
//$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);



      header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0"); 
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=".$local_file);
        header("Content-Transfer-Encoding: binary ");
readfile($filename); 

//echo($filename);
// try to download $server_file and save to $local_file
// if (ftp_get($conn_id, $local_file, $server_file, FTP_BINARY)) {
//     echo "success";
// }
// else {
//     echo "There was a problem\n";
// }
// close the connection
//ftp_close($conn_id);

?>