<?
$file=$_POST['file'];
$uid=$_POST['uid'];
$filename = "ftp://admin@ultimatesoft-il.com:mikepe0301@ftp.ultimatesoft-il.com/htdocs/user_data/".$uid."/".$file;

 echo  $filename;



?>