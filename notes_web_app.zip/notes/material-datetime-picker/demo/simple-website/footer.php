			</div>
		</div>
		<div id="footer-wrapper">
			<div class="container">
				<div class="row">
					<div class="12u">
						<div id="copyright">
							<a href="http://www.thesoftwareguy.in" target="_blank">&copy; 2013 - <?php echo date("Y"); ?> www.thesoftwareguy.in</a> All rights Reserved. | Template taken from: <a href="http://html5up.net"> &copy; HTML5 UP</a> 
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- ********************************************************* -->
	<script src="js/config.js"></script>
    <script src="js/skel.min.js"></script>
    <script src="js/skel-panels.min.js"></script>
	</body>
</html>