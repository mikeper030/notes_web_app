<?php

    readfile("login.html");

?>