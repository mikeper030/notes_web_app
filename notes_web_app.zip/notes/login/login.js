var config = {
    apiKey: "AIzaSyC4XM3FYrsoi1c5tmPIBU9KNWjULXRyoFE",
    authDomain: "notes-207711.firebaseapp.com",
    databaseURL: "https://notes-207711.firebaseio.com",
    projectId: "notes-207711",
    storageBucket: "notes-207711.appspot.com",
    messagingSenderId: "32544248955"
  };
firebase.initializeApp(config);
    
function signUp(){
 
 var email = document.getElementById('i_email').value;
      var password = document.getElementById('i_pass').value;
      var confirm=document.getElementById('i_pass2').value;
       if (email.length < 4) {
        alert('Please enter an email address.');
        return;
      }
      if (password.length < 4 ) {
        alert('Please enter a password.');
        return;
      }
      // Sign in with email and pass.
      // [START createwithemail]
     if(password==confirm){
  firebase.auth().createUserWithEmailAndPassword(email,password).catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // [START_EXCLUDE]
        if (errorCode == 'auth/weak-password') {
          alert('סיסמא חלשה מדי.');
        } else {
          alert(errorMessage);
        }
        console.log(error);
        // [END_EXCLUDE]
      });
     }else{
       alert("הסיסמאות אינן תואמות");
     }
    
   
  
  
}

$(document).ready(function(event){

    initApp();

});
window.on = function() {
     // initApp();
};
function initApp() {
      // Listening for auth state changes.
      // [START authstatelistener]
      firebase.auth().onAuthStateChanged(function(user) {
        // [START_EXCLUDE silent]
  
        // [END_EXCLUDE]
        if (user) { 
          // User is signed in.
          var displayName = user.displayName;
          var emailt = user.email;
          var emailVerified = user.emailVerified;
          var photoURL = user.photoURL;
          var isAnonymous = user.isAnonymous ;
          var uid = user.uid;
          var providerData = user.providerData;
         // alert(email); 
         $.ajax({
            url:"index.php", //the page containing php script
            type: "post", //request type,
            
           data: {login: "ok", name: displayName, email: emailt},
            success: function(response){
           if(response=="ok")
            window.location = 'https://ultimatesoft-il.com/notes/index.php';
    
   },
   error: function(xhr, status, error) {
  
}
         });
      
         
         
        } else {
          // User is signed out.
         
        
         
        }
       
      });
    
   
  
}

 function login() {
      if (firebase.auth().currentUser) {
        // [START signout]
        //firebase.auth().signOut();
        // [END signout]
      } else {
        var email = document.getElementById('i_email').value;
        var password = document.getElementById('i_pass').value;
        if (email.length < 4) {
          alert('Please enter an email address.');
          return;
        }
        if (password.length < 4) {
          alert('Please enter a password.');
          return;
        }
        // Sign in with email and pass.
        // [START authwithemail]
        firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;
          // [START_EXCLUDE]
          if (errorCode === 'auth/wrong-password') {
            alert('Wrong password.');
              return;
          } else {
            alert(errorMessage);
            return;
          }
          console.log(error);
         
          // [END_EXCLUDE]
        });
       
      
      
      }
     
    }
 
function sendPasswordReset() {
      
    var email = document.getElementById('i_email').value;
      // [START sendpasswordemail]
      firebase.auth().sendPasswordResetEmail(email).then(function() {
        // Password Reset Email Sent!
        // [START_EXCLUDE]
        alert('Password Reset Email Sent!');
        // [END_EXCLUDE]
      }).catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // [START_EXCLUDE]
        if (errorCode == 'auth/invalid-email') {
          alert(errorMessage);
        } else if (errorCode == 'auth/user-not-found') {
          alert(errorMessage);
        }
        console.log(error);
        // [END_EXCLUDE]
      });
      // [END sendpasswordemail];
    }

function loginWithFacebook(){
   if (!firebase.auth().currentUser) {
        // [START createprovider]
        var provider = new firebase.auth.FacebookAuthProvider();
        // [END createprovider]
        // [START addscopes]
        provider.addScope('user_birthday');
        // [END addscopes]
        // [START signin]
        firebase.auth().signInWithPopup(provider).then(function(result) {
          // This gives you a Facebook Access Token. You can use it to access the Facebook API.
          var token = result.credential.accessToken;
          // The signed-in user info.
          var user = result.user;
          // [START_EXCLUDE]
         alert(user);
          // [END_EXCLUDE]
        }).catch(function(error) {
          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;
          // The email of the user's account used.
          var email = error.email;
          // The firebase.auth.AuthCredential type that was used.
          var credential = error.credential;
          // [START_EXCLUDE]
          if (errorCode === 'auth/account-exists-with-different-credential') {
            alert('You have already signed up with a different auth provider for that email.');
            // If you are using multiple auth providers on your app you should handle linking
            // the user's accounts here.
          } else {
            alert(error);
          }
          // [END_EXCLUDE]
        });
        // [END signin]
      } else {
        // [START signout]
        firebase.auth().signOut();
        // [END signout]
      }
      // [START_EXCLUDE]
     
      // [END_EXCLUDE]
}
 function initSignUp(){
         $("#title").text("הרשמה");
         $("#nav_main").html('<a  class="txt2 hov1" style="cursor:pointer;" onClick="initLogin()">כניסה</a>');
         $("#action").html('<span style="cursor:pointer" class="login100-form-btn" onClick="signUp()">הרשמה</span>')
          $("#append").append('<div class="wrap-input100 validate-input m-b-25" data-validate = "הכנס סיסמא"><input  id ="i_pass2"class="input100" type="password" name="pass" placeholder= "סיסמא שוב"><span class="focus-input100"></span></div>');
         
    }
function initLogin(){
     $("#title").text("כניסה");
       $("#nav_main").html('<a  class="txt2 hov1" style="cursor:pointer;" onClick="initLogin()">הרשמה</a>');
        $("#append").html('<div class="wrap-input100 validate-input m-b-25" data-validate = "הכנס סיסמא"><input  id ="i_pass"class="input100" type="password" name="pass" placeholder="סיסמא"><span class="focus-input100"></span></div>');
       $("#action").html('	<span style="cursor:pointer" class="login100-form-btn" onClick=login()>כניסה</span>');
}    
function initPass(){
    $("#append").html('');
     $("#title").text("איפוס סיסמא");
      $("#action").html('<span style="cursor:pointer" class="login100-form-btn" onClick="sendPasswordReset()">שלח</span>');
       $("#nav_main").html('');
}   
function signInWithGoogle() {
      if (!firebase.auth().currentUser) {
        // [START createprovider]
        var provider = new firebase.auth.GoogleAuthProvider();
        // [END createprovider]
        // [START addscopes]
        provider.addScope('https://www.googleapis.com/auth/contacts.readonly');
        // [END addscopes]
        // [START signin]
        firebase.auth().signInWithPopup(provider).then(function(result) {
          // This gives you a Google Access Token. You can use it to access the Google API.
          var token = result.credential.accessToken;
          // The signed-in user info.
          var user = result.user;
          // [START_EXCLUDE]
      
          // [END_EXCLUDE]
        }).catch(function(error) {
          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;
          // The email of the user's account used.
          var email = error.email;
          // The firebase.auth.AuthCredential type that was used.
          var credential = error.credential;
          // [START_EXCLUDE]
          if (errorCode === 'auth/account-exists-with-different-credential') {
            alert('You have already signed up with a different auth provider for that email.');
            // If you are using multiple auth providers on your app you should handle linking
            // the user's accounts here.
          } else {
            console.error(error);
          }
          // [END_EXCLUDE]
        });
        // [END signin]
      } else {
        // [START signout]
        firebase.auth().signOut();
        // [END signout]
      }
      // [START_EXCLUDE]
   
      // [END_EXCLUDE]
    }