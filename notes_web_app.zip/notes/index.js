   
   var navclosed=true;
   var all_items=[];
   var trashed_items=[];
   var categories=[];
   var archived_items=[];
   var reminders_items=[];
   var uncategorized_items=[];
   var current_note;
   var current_mode;
   var checklistMax=0;
  var mousePressed = false;
  var audio;
   var elapsedTime;
   var duration;
  var audioBlob;
var lastX, lastY;
var ctx;

    function enableFocus(f){
        var a=0;
         $('input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=number], input[type=search], input[type=date], input[type=time], textarea').each(function (element, i) {
            if(a==f){ 
    if ((element.value !== undefined && element.value.length > 0) || $(this).attr('placeholder') !== null) {
        $(this).siblings('label').addClass('active');
         $(this).siblings('i').addClass('active');
        $(this).focusin();
    }
    }
    a++;
    
});
    }    
    function disableFocus(f){
        var a=0;
         $('input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=number], input[type=search], input[type=date], input[type=time], textarea').each(function (element, i) {
        
   if(a==f){
        if ((element.value !== undefined && element.value.length > 0) || $(this).attr('placeholder') !== null) {
        $(this).siblings('label').removeClass('active');
         $(this).siblings('i').removeClass('active');
              $(this).blur();
                    

    }
   }
    a++;
});
     
    }    
 
      function openNav(x) {
          x.classList.toggle("change");

    if(navclosed){ 
        navclosed=false;
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginRight = "250px";
  $("#menu").hide();      
    }else{
        navclosed=true;
        closeNav();
    }
          
}
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginRight= "0";
      $("#menu").show();          

}  
//========================================firebase config and messaging===================================================
  var config = {
    apiKey: "AIzaSyC4XM3FYrsoi1c5tmPIBU9KNWjULXRyoFE",
    authDomain: "notes-207711.firebaseapp.com",
    databaseURL: "https://notes-207711.firebaseio.com",
    projectId: "notes-207711",
    storageBucket: "notes-207711.appspot.com",
    messagingSenderId: "32544248955"
  };
  firebase.initializeApp(config);
  const messaging = firebase.messaging();
  messaging.usePublicVapidKey("BMEjPHK-LgaqF0EcYgR7f7Mdx-nW-F3M0-2PZpm2qdg2JucWRpwxfLcCoDSAUeybe0D0pyzeqTZ9Kz_oATzXdOo");
messaging.onMessage((payload) => {
  const notificationTitle = payload.notification.title;
    const notificationOptions = {
        body: payload.notification.body,
        icon: payload.notification.icon,        
    };
    if($('#id-name--1').is(":checked")){
    if (!("Notification" in window)) {
        console.log("This browser does not support system notifications");
    }
    // Let's check whether notification permissions have already been granted
    else if (Notification.permission === "granted") {
        // If it's okay let's create a notification
        var notification = new Notification(notificationTitle,notificationOptions);
        notification.onclick = function(event) {
            event.preventDefault(); // prevent the browser from focusing the Notification's tab
            window.open(payload.notification.click_action , '_blank');
            notification.close();
        }
    }
  // ...
    }
});

//=========================================================================================================================  
  
   function mySearch(){
   var input, filter, table, tr, td, i, txtValue;
  input = $("#search_filter").val();
  filter = input.toUpperCase();
  
  $('#lst').find('div').find('h2').each(
    function(){
		txtValue=this.innerText;
		var id=$(this).attr('id');
		if (txtValue.toUpperCase().indexOf(filter) > -1) {
      $('#card'+id).css({"display":""});
      } else {
           $('#card'+id).css({"display":"none"});

      }
    });
 
   }
   function nav_action(mode){
    loadDataFromFirebase(mode);
   }
   function initSideNav(mode){
      
	    var ref = firebase.database().ref(); 
		ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").once("value", function(snapshot) {
       if(snapshot){
		$('#mySidenav').html("");
		
	if(all_items.length>0){
	 var st = tmpl("nav_all_template");
    $('#mySidenav').append(st);
	     if(mode=="all")
		$("#n_a").css('background-color', '#0087a2');	 

	}
	if(trashed_items.length>0){
	 var st = tmpl("nav_trash_template");
     $('#mySidenav').append(st);
	  if(mode=="trash")
		$("#n_t").css('background-color', '#0087a2');
	}
	if(archived_items.length>0){
	 var st = tmpl("nav_archive_template");
     $('#mySidenav').append(st);
	  if(mode=="archive")
		$("#n_ar").css('background-color', '#0087a2');
	}
	if(reminders_items.length>0){
	 var st = tmpl("nav_reminder_template");
     $('#mySidenav').append(st);
	  if(mode=="reminder")
		$("#n_re").css('background-color', '#0087a2');
	}
	
	var st=tmpl("nav_border");
		$('#mySidenav').append(st);
	   snapshot.forEach(function(child) {
	  var categorie = child.val();
    //append data to list  
	
	var data = {
                    title: categorie.name,
                    id: categorie.id,
					content:categorie.description,
					color:toColor(categorie.color),
					count:categorie.count
               };
                // var data={title:album.title,id:i};

                
                var st = tmpl("nav_categorie_template", data);

                $('#mySidenav').append(st);
				if(isNumeric(mode)){
				$("#categorie"+mode).css('background-color', '#0087a2');
		
	
				
				}
	
  });
   	 $(".cats").unbind().on('contextmenu', function(e) {
   	     e.preventDefault();
  var top = e.pageY - 10;
  var left = e.pageX - 90;
  $("#context-menu").css({
    display: "block",
    top: top,
    left: left
  }).addClass("show");
   $("#context-menu").data('originalElement', this);
  return false; //blocks default Webbrowser right click menu
}).on("click", function() {
  $("#context-menu").removeClass("show").hide();

});

$("#context-menu a").on("click", function() {
    var originalElement = $("#context-menu").data('originalElement');
   var c_id=originalElement.id.replace("categorie","");
     deleteCategory(c_id);
  
  $(this).parent().removeClass("show").hide();
  
});
$('body').click(function() {
    $("#context-menu").removeClass("show").hide();
});
}else{
$('#mySidenav').html("");
	if(all_items.length>0){
	 var st = tmpl("nav_all_template");
    $('#mySidenav').append(st);
	     if(mode=="all")
		$("#n_a").css('background-color', '#0087a2');	 

	}
	if(trashed_items.length>0){
	 var st = tmpl("nav_trash_template");
     $('#mySidenav').append(st);
	  if(mode=="trash")
		$("#n_t").css('background-color', '#0087a2');
	}
	if(archived_items.length>0){
	 var st = tmpl("nav_archive_template");
     $('#mySidenav').append(st);
	  if(mode=="trash")
		$("#n_t").css('background-color', '#0087a2');
	}
	if(reminders_items.length>0){
	 var st = tmpl("nav_reminder_template");
     $('#mySidenav').append(st);
	  if(mode=="trash")
		$("#n_t").css('background-color', '#0087a2');
	}
}
 
});
    
   }
  function deleteCategory(id){
       $('#modalConfirmDeletec').modal('show');
       $("#d_c_confirm").on('click',function() {
         var ref = firebase.database().ref(); 
         
            ref.child("users").child( firebase.auth().currentUser.uid).child("v2").child("categories").child(id).remove().then(function(snapshot) {
              
                    showSnackbar('נמחק');
                       ref.child('users').child(firebase.auth().currentUser.uid).child("v2").child("notes").once("value", function(snap) {
                       if(snap){ 
                        snap.forEach(function(child) {
                        	var note = JSON.parse(child.val());
                            	var hasCategory =typeof note.baseCategory !== 'undefined';
                            if(hasCategory&&note.baseCategory.id==id){
                             delete note.baseCategory;
                            ref.child('users').child(firebase.auth().currentUser.uid).child("v2").child("notes").child(note.creation).set(JSON.stringify(note));
                             }

                         });
                         loadDataFromFirebase(current_mode);
                     }
        
              
      
             
       }, function(error) {
            showSnackbar(error);
       });
  }, function(error) {
            showSnackbar(error);
       });
       });
  }
   function toColor(num) {
    num >>>= 0;
    var b = num & 0xFF,
        g = (num & 0xFF00) >>> 8,
        r = (num & 0xFF0000) >>> 16,
        a = ( (num & 0xFF000000) >>> 24 ) / 255 ;
    return "rgba(" + [r, g, b, a].join(",") + ")";
}
   function initList(mode){
	   initSideNav(mode);
   $("#lst").html("");   
   if(mode=="all"){
		for(var i=0;i<all_items.length;i++){
      var note = all_items[i];
	   var data = {
                    title: note.title,
                    id: note.creation,
					content:note.content
					
               };
              	var hasCategory =typeof note.baseCategory !== 'undefined';
              	if(hasCategory){
              	    data.color=toColor(note.baseCategory.color);
              	}
                // var data={title:album.title,id:i};

                //console.log(JSON.stringify(x, null, 2));
                var st = tmpl("card", data);

      $('#lst').append(st);
     }
	   if(all_items.length>0){
		    var note = all_items[0];
	   loadNote(note.creation);
	   }
	}
	else
	if(mode=="trash"){
		  
		
		for(var i=0;i<trashed_items.length;i++){
      var note = trashed_items[i];
	   var data = {
                    title: note.title,
                    id: note.creation,
					content:note.content
               };
                // var data={title:album.title,id:i};
	           var hasCategory =typeof note.baseCategory !== 'undefined';
              	if(hasCategory){
              	    data.color=toColor(note.baseCategory.color);
              	}
                //console.log(JSON.stringify(x, null, 2));
                var st = tmpl("card", data);

                $('#lst').append(st);
				
       }
	   if(trashed_items.length>0){
	    var note = trashed_items[0];
	
	   loadNote(note.creation);
	   }
	}
	else
	if(isNumeric(mode)){
		  
		
		for(var i=0;i<all_items.length;i++){
      var note = all_items[i];
	var hasCategory =typeof note.baseCategory !== 'undefined';
	
      if(hasCategory && note.baseCategory.id==mode){	  
	  var data = {
                    title: note.title,
                    id: note.creation,
					content:note.content
               };
                // var data={title:album.title,id:i};

                //console.log(JSON.stringify(x, null, 2));
               	var hasCategory =typeof note.baseCategory !== 'undefined';
              	if(hasCategory){
              	    data.color=toColor(note.baseCategory.color);
              	}
                var st = tmpl("card", data);

                $('#lst').append(st);
				
         }
		}
		
	   
	}
	else
	if(mode=="uncategorized"){
		  
		
		for(var i=0;i<uncategorized_items.length;i++){
      var note = uncategorized_items[i];
	
	  var data = {
                    title: note.title,
                    id: note.creation,
					content:note.content
               };
                // var data={title:album.title,id:i};

                //console.log(JSON.stringify(x, null, 2));
               	var hasCategory =typeof note.baseCategory !== 'undefined';
              	if(hasCategory){
              	    data.color=toColor(note.baseCategory.color);
              	}
                var st = tmpl("card", data);

                $('#lst').append(st);
				
         
		}
		if(uncategorized_items.length>0){
		    var note = uncategorized_items[0];
	   loadNote(note.creation);
	   }
	   
	}
	else
	if(mode=="archive"){
		  
		
		for(var i=0;i<archived_items.length;i++){
      var note = archived_items[i];
		  
	  var data = {
                    title: note.title,
                    id: note.creation,
					content:note.content
               };
                // var data={title:album.title,id:i};

                //console.log(JSON.stringify(x, null, 2));
               	var hasCategory =typeof note.baseCategory !== 'undefined';
              	if(hasCategory){
              	    data.color=toColor(note.baseCategory.color);
              	}
                var st = tmpl("card", data);

                $('#lst').append(st);
				
         
		}
		if(archived_items.length>0){
		    var note = archived_items[0];
	   loadNote(note.creation);
	   }
	   
	}
	else
	if(mode=="reminder"){
		  
		
		for(var i=0;i<reminders_items.length;i++){
      var note = reminders_items[i];	
	  var data = {
                    title: note.title,
                    id: note.creation,
					content:note.content
               };
                // var data={title:album.title,id:i};

                //console.log(JSON.stringify(x, null, 2));
               	var hasCategory =typeof note.baseCategory !== 'undefined';
              	if(hasCategory){
              	    data.color=toColor(note.baseCategory.color);
              	}
                var st = tmpl("card", data);

                $('#lst').append(st);
				
         }
		
		
	   
	}
	if(archived_items.length>0){
		    var note = archived_items[0];
	   loadNote(note.creation);
	   }

  }
  function new_photo_note(){
	current_note="undefined";	
  $("#note_container").html("");   
   var st = tmpl("text_note");
  $('#note_container').append(st);
     $('#upload').click(function(){
		    showProgress(); 
           var file_data = $('#file').prop('files')[0];
            if(file_data != undefined) {
                 if($('#file').prop('files')[0].size<2621440){
                var form_data = new FormData();                  
                form_data.append('file', file_data);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',$('#file').prop('files')[0].name);
                $.ajax({
                    method: 'post',
                    url: 'php/upload.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=0;
							attachment.name==$('#file').prop('files')[0].name;
							attachment.mime_type=$('#file').prop('files')[0].type;
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+$('#file').prop('files')[0].name;
                            var temp = new NoteObject();
						var d = new Date();
                          var id = d.getTime();
						  temp.creation=id;
	                      temp.content=$('#text_content_field').val();
						  temp.title=$('#text_title_field').val();
						   temp.lastModification=id;
                            temp.attachmentsList[0]=attachment;
                           	 var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              
                  loadDataFromFirebase(current_mode);
                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
              

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
            }
        }else{
             hideProgress();
            showSnackbar("גודל הקובץ לא יכול להיות יותר מ 2.5 מגה בייט");
        }
})

var picker = new MaterialDatetimePicker({})
      .on('submit', function(d) {
           showProgress();
           var temp=new NoteObject();
         var id = d.getTime();
						  temp.creation=id;
	                      temp.content=$('#text_content_field').val();
						  temp.title=$('#text_title_field').val();
						   temp.lastModification=id;
                          

                 
                           temp.alarm=Date.parse(d);
       
        var ref = firebase.database().ref(); 
        ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              

                 showSnackbar( d.toLocaleString("he-IL")+' :נקבעה התראה ל');
                 hideProgress();
              

               
              

            }, function(error) {
                showSnackbar(error);
            });
       
       
      });

    var el = document.querySelector('.c-datepicker-btn');
    el.addEventListener('click', function() {
      picker.open();
    }, false);
$("#camera_action").unbind().click(function() {
    if(current_note!="undefined")
    takePic(temp);
    else{
        var o = new NoteObject();
        takePic(o);
    }
});
$("#canvas_action").unbind().click(function() {
    if(current_note!="undefined")
    draw(temp);
    else{
        var o = new NoteObject();
        draw(o);
    }
});
$("#record_action").unbind().click(function() {
    if(current_note!="undefined")
    record(temp);
    else{
        var o = new NoteObject();
        record(o);
    }
});
if(current_note!="undefined")
    takePic(temp);
    else{
        var o = new NoteObject();
        takePic(o);
    }
  }
  function showInnerProgress(){
         $("#progressBarInner").css("visibility", "visible");
  }
  function hideInnerProgress(){
        $("#progressBarInner").css("visibility", "hidden");
  }
  function new_checklist_note(){
	 current_note="undefined";	
   $("#note_container").html("");   
   var st = tmpl("checklist_note_blank");
   $('#note_container').append(st);
   initCheckCommands();
    $('#upload').click(function(){
		    showProgress(); 
           var file_data = $('#file').prop('files')[0];
            if(file_data != undefined) {
                  if($('#file').prop('files')[0].size<2621440){
                var form_data = new FormData();                  
                form_data.append('file', file_data);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',$('#file').prop('files')[0].name);
                $.ajax({
                    method: 'post',
                    url: 'php/upload.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=0;
								attachment.name==$('#file').prop('files')[0].name;
							attachment.mime_type=$('#file').prop('files')[0].type;
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+$('#file').prop('files')[0].name;
                            var temp = new NoteObject();
						var d = new Date();
							temp.attachmentsList[0]=attachment;
                         var d = new Date();
                          var id = d.getTime();
						  temp.creation=id;	
						   temp.lastModification=id;
	                      temp.content=$('#text_content_field').val();
						  temp.title=$('#text_title_field').val();
                            temp.attachmentsList[0]=attachment;                           	
							var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              
               loadDataFromFirebase(current_mode);
                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
              

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
            }else{
                 hideProgress();
            showSnackbar("גודל הקובץ לא יכול להיות יותר מ 2.5 מגה בייט");
            }
        }
})

    var picker = new MaterialDatetimePicker({})
      .on('submit', function(d) {
           showProgress();
           var temp=new NoteObject();
         var id = d.getTime();
						  temp.creation=id;
	                      temp.content=$('#text_content_field').val();
						  temp.title=$('#text_title_field').val();
						   temp.lastModification=id;
                          

                 
                           temp.alarm=Date.parse(d);
       
        var ref = firebase.database().ref(); 
        ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              

                                 showSnackbar( d.toLocaleString("he-IL")+' :נקבעה התראה ל');

                 hideProgress();
              

               
              

            }, function(error) {
                showSnackbar(error);
            });
       
      });

    var el = document.querySelector('.c-datepicker-btn');
    el.addEventListener('click', function() {
      picker.open();
    }, false);
$("#camera_action").unbind().click(function() {
    if(current_note!="undefined")
    takePic(temp);
    else{
        var o = new NoteObject();
        takePic(o);
    }
});
$("#canvas_action").unbind().click(function() {
    if(current_note!="undefined")
    draw(temp);
    else{
        var o = new NoteObject();
        draw(o);
    }
});
$("#record_action").unbind().click(function() {
    if(current_note!="undefined")
    record(temp);
    else{
        var o = new NoteObject();
        record(o);
    }
});
  }
  
  function new_text_note(){
    current_note="undefined";	  
  $("#note_container").html("");   
  var st = tmpl("text_note");
  $('#note_container').append(st);
  
var picker = new MaterialDatetimePicker({})
      .on('submit', function(d) {
            showProgress();
           var temp=new NoteObject();
         var id = d.getTime();
						  temp.creation=id;
	                      temp.content=$('#text_content_field').val();
						  temp.title=$('#text_title_field').val();
						   temp.lastModification=id;
                          

                 
                           temp.alarm=Date.parse(d);
       
        var ref = firebase.database().ref(); 
        ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              

                                 showSnackbar( d.toLocaleString("he-IL")+' :נקבעה התראה ל');

                 hideProgress();
              

               
              

            }, function(error) {
                showSnackbar(error);
            });
       
      });

    var el = document.querySelector('.c-datepicker-btn');
    el.addEventListener('click', function() {
      picker.open();
    }, false);
$('#upload').click(function(){
		    showProgress(); 
           var file_data = $('#file').prop('files')[0];
            if(file_data != undefined) {
                if($('#file').prop('files')[0].size<2621440){
                var form_data = new FormData();                  
                form_data.append('file', file_data);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',$('#file').prop('files')[0].name);
                $.ajax({
                    method: 'post',
                    url: 'php/upload.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=0;
								attachment.name==$('#file').prop('files')[0].name;
							attachment.mime_type=$('#file').prop('files')[0].type;
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+$('#file').prop('files')[0].name;
                            var temp = new NoteObject();
						var d = new Date();
                          var id = d.getTime();
                          temp.creation=id;
                          temp.lastModification=id;
						 temp.content=$('#text_content_field').val();
						  temp.title=$('#text_title_field').val();
                            temp.attachmentsList[0]=attachment;
                           	 var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              
  loadDataFromFirebase(current_mode);
                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
              

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
            }else{
             hideProgress();
            showSnackbar("גודל הקובץ לא יכול להיות יותר מ 2.5 מגה בייט");
            }
        }
})
$("#camera_action").unbind().click(function() {
    if(current_note!="undefined")
    takePic(temp);
    else{
        var o = new NoteObject();
        takePic(o);
    }
});
$("#canvas_action").unbind().click(function() {
    if(current_note!="undefined")
    draw(temp);
    else{
        var o = new NoteObject();
        draw(o);
    }
});
$("#record_action").unbind().click(function() {
    if(current_note!="undefined")
    record(temp);
    else{
        var o = new NoteObject();
        record(o);
    }
});
  }
  function isNumeric(num){
  return !isNaN(num)
}
function shareNote(){
window.open('mailto:test@example.com?subject='+current_note.title+'&body='+current_note.content);
}

  function initNote( array,id){
      hideProgress();
  for(var i=0;i<array.length;i++){
    var temp = array[i];
	if(temp.creation==id){
	   var d= new Date(temp.creation);
	    var e;
	   if(temp.lastModification!=0)
	    e= new Date(temp.lastModification);
	    
	    var data = {
                    title: temp.title,
                    id: temp.creation,
					content:temp.content,
				    created:d.toLocaleString("he-IL")
                  };
                 if(temp.lastModification!=0){
                     data.modified=e.toLocaleString("he-IL");
                 }
                // var data={title:album.title,id:i};
                if(!temp.checklist){
				var st = tmpl("text_note", data);
                $('#note_container').html("");
                $('#note_container').append(st);
				}else{
				data.itemsFormatted=[];
				
				var lines=temp.content.split('\n');
				var itemsFormatted=[];
				for(var i=0;i<lines.length;i++){
				var item={checked:"uncheck",title:"",ind:i};
				var str=lines[i];
				if(str.search("[ ]")==1){
				item.title=str.replace("[ ]","");
				}else{
				item.checked="checked";
				item.title=str.replace("[x]","");
				}	
				data.itemsFormatted.push(item);
				checklistMax+=1;
				}
				checklistMax+=1;
				var st = tmpl("checklist_note", data);
                $('#note_container').html("");
                $('#note_container').append(st);
				 initCheckCommands();
				}
		
				if (temp.attachmentsList.length>0 ){
				  
				     $("#attachmentBtn").css("visibility","visible");
				     $("#attachmentBtn").attr("disabled", true);
				     
                         if(temp.attachmentsList[0].mime_type.includes("image")){
				       $("#attachmentBtn").click(function(){
                     
                      $('#attachmentModal').modal('show');
                     $('#attachmentModal').on('hidden.bs.modal', function () {
                      $("#attachment_body").html("");
	                 
                    })
                        
                      }); 
				      var filename=temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, '');
					showInnerProgress();
                     var form_data = new FormData();                  
                     form_data.append('file', filename);
                     form_data.append('uid',firebase.auth().currentUser.uid);
                     $.ajax({
                      url: "php/retreive.php",
                        method: "POST",
                          data: form_data,
                           contentType: false,
                           processData: false,
                            success: function (result) {
                              hideInnerProgress();
                           $("#attachmentBtn").attr("disabled", false);
                            var data={data:result};
                            var img = tmpl("image",data);
                            $("#attachment_body").html(img);
                         }
                  });
                  
				    
    	}else{
    	    if(temp.attachmentsList[0].uriPath.includes("pdf")){
    	     showInnerProgress();
    	         $("#attachmentBtn").click(function(){
                     
                      $('#attachmentModal').modal('show');
                     $('#attachmentModal').on('hidden.bs.modal', function () {
                      $("#attachment_body").html("");
	                 
                    })
                        
                      }); 
    	         var filename=temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, '');
					
                     var form_data = new FormData();                  
                     form_data.append('file', filename);
                     form_data.append('uid',firebase.auth().currentUser.uid);
                     $.ajax({
                      url: "php/retreive.php",
                        method: "post",
                          data: form_data,
                           contentType: false,
                           processData: false,
                            success: function (result) {
                                hideInnerProgress();
                           $("#attachmentBtn").attr("disabled", false);
                            var data={data:result};
                            var doc = tmpl("document",data);
                            $("#attachment_body").html(doc);
                         }
                  });
    	    }else{
    	        if(temp.attachmentsList[0].uriPath.includes("amr")){
    	            var filename=temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, '');
					 $("#attachmentBtn").text("הורדת הקלטה"); 
					 $("#attachmentBtn").attr("disabled", false);
					  $("#attachmentBtn").click(function(){
                    
	                    
                        window.open("http://ultimatesoft-il.com/notes/php/download.php?file="+filename+"&"+"uid="+firebase.auth().currentUser.uid);
                         
                           
                        
                  });
    	        }else{
    	          var filename=temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, '');
					 $("#attachmentBtn").text("הורדת קובץ מצורף"); 
					 $("#attachmentBtn").attr("disabled", false);
					  $("#attachmentBtn").click(function(){
                    
	                    
                        window.open("http://ultimatesoft-il.com/notes/php/download.php?file="+filename+"&"+"uid="+firebase.auth().currentUser.uid);
                         
                           
                        
                  });
                   
                        
    	          }     
				
    	    }
    	}
				    
	}

	
 $('#upload').click(function(){
		    showProgress(); 
           var file_data = $('#file').prop('files')[0];
           
            if(file_data != undefined) {
              
                if($('#file').prop('files')[0].size<2621440){
                var form_data = new FormData();                  
                form_data.append('file', file_data);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',$('#file').prop('files')[0].name);
                $.ajax({
                    method: 'post',
                    url: 'php/upload.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=0;
								attachment.name==$('#file').prop('files')[0].name;
							attachment.mime_type=$('#file').prop('files')[0].type;
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+$('#file').prop('files')[0].name;
                            temp.lastModification=d.getTime();
                            if(temp.attachmentsList.length>0){
                              
                                //first delete the old file
                     var form_data = new FormData();                  
                form_data.append('file', temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, ''));
                form_data.append('uid',firebase.auth().currentUser.uid);
                     $.ajax({
                      url: "php/delete.php",
                        method: "POST",
                          data: form_data,
                           contentType: false,
                           processData: false,
                            success: function (result) {
                           
                         }
                  });
                            }
                            temp.attachmentsList[0]=attachment;
                          	 var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              

                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
              

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
            }else{
                hideProgress();
                showSnackbar("גודל הקובץ לא יכול להיות יותר מ 2.5 מגה בייט");
            }
     }
})


var picker = new MaterialDatetimePicker({})
      .on('submit', function(d) {
        current_note.alarm=Date.parse(d);
        showProgress();
        var ref = firebase.database().ref(); 
        ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(current_note.creation).set(JSON.stringify(current_note)).then(function(snapshot) {
              

                                showSnackbar( d.toLocaleString("he-IL")+' :נקבעה התראה ל');

                 hideProgress();
              

            }, function(error) {
                showSnackbar(error);
            });
      });

    var el = document.querySelector('.c-datepicker-btn');
    el.addEventListener('click', function() {
      picker.open();
    }, false);

	current_note=temp;
	animFields();
   
$("#camera_action").unbind().click(function() {
    if(current_note!="undefined")
    takePic(temp);
    else{
        var o = new NoteObject();
        takePic(o);
    }
});
$("#canvas_action").unbind().click(function() {
    if(current_note!="undefined")
    draw(temp);
    else{
        var o = new NoteObject();
        draw(o);
    }
});
$("#record_action").unbind().click(function() {
    if(current_note!="undefined")
    record(temp);
    else{
        var o = new NoteObject();
        record(o);
    }
});
	return true;
	}
	
   }
   return false;
  }
  
  
  function record(temp){
          
 $('#recordModal').modal('show');
 

$('#record_modal_confirm').unbind().on('click', function(evt) {
  
   //save
    var form_data = new FormData();                  
                var d = new Date();
				
               
              
             

                if(typeof audioBlob !="undefined"){
                    
                var id=makeid(5);
                var reader = new window.FileReader();
                reader.readAsDataURL(audioBlob); 
               
                reader.onloadend = function() {
                 base64 = reader.result;
                 base64 = base64.split(',')[1];
                
                 form_data.append('file', base64);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',id+".amr");
               
                $.ajax({
                    method: 'post',
                    url: 'php/upload_base64.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                      
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=duration;
							attachment.name=id+".amr";
							attachment.mime_type="audio/amr";
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+id+".amr";
                            temp.lastModification=d.getTime();
                            if(temp.attachmentsList.length>0){
                              
                                //first delete the old file
                     var form_data = new FormData();                  
                form_data.append('file', temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, ''));
                form_data.append('uid',firebase.auth().currentUser.uid);
                     $.ajax({
                      url: "php/delete.php",
                        method: "POST",
                          data: form_data,
                           contentType: false,
                           processData: false,
                            success: function (result) {
                           
                         }
                  });
                            }
                            if(temp.creation==0){
                                 var d = new Date();
                                 temp.creation=d.getTime();
                               	temp.title=$('#text_title_field').val();
	                           
                               //check if the note is checklist
                                if($("#add-todo").is(":visible")){
                                     var i=0;
	                                  var saveString=""; 
	                               
                                     $('#todo-list').find('div').each(function() { 
    
                                          var id = $(this).attr('id');
                                              if(id!="add-todo"&&id!="text_title_wrapper"){	 
                                        	 if($("#"+i).attr("checked")=="checked"||$('#'+i).prop('checked')){
	                                         saveString+="[x] ";
	                                        } else{
	                                        saveString+="[ ] ";
	                                        }	 
	                                        saveString+=$("#label"+i).text().trim();
	                                        saveString+="\n";
                                            i++;
	 }
    
});
  saveString=saveString.replace(/\n$/, "");
  current_note.content=saveString;
                                }else{
                                     temp.content=$('#text_content_field').val();
                                }
                            }
                            temp.attachmentsList[0]=attachment;
                          	var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              
                 loadDataFromFirebase(current_mode);
                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
                

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
                }
             audioBlob="undefined"
            }
  });

}
  function InitThis() {
    ctx = $("#myCanvas")[0].getContext('2d');

    $('#myCanvas').mousedown(function (e) {
        mousePressed = true;
        Draw(e.pageX - $(this).offset().left, e.pageY - $(this).offset().top, false);
    });

    $('#myCanvas').mousemove(function (e) {
        if (mousePressed) {
            Draw(e.pageX - $(this).offset().left, e.pageY - $(this).offset().top, true);
        }
    });

    $('#myCanvas').mouseup(function (e) {
        mousePressed = false;
    });
	    $('#myCanvas').mouseleave(function (e) {
        mousePressed = false;
    });
}
function addTimeStamp(){
    var text= $('#text_content_field').val();
    var date = new Date(Date.now());
    
    var formatted=date.toLocaleString("he-IL")
    text+="\n\n";
    text+=formatted;
    $('#text_content_field').text(text);
}
function Draw(x, y, isDown) {
    if (isDown) {
        ctx.beginPath();
        ctx.strokeStyle = $('#selColor').val();
        ctx.lineWidth = $('#selWidth').val();
        ctx.lineJoin = "round";
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(x, y);
        ctx.closePath();
        ctx.stroke();
    }
    lastX = x; lastY = y;
}
	
function clearArea() {
    // Use the identity matrix while clearing the canvas
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}
  
  function draw(temp){
       
 $('#canvasModal').modal('show');
 
  InitThis();

$('#canvas_modal_confirm').unbind().on('click', function(evt) {
  
   //save
    var form_data = new FormData();                  
                var d = new Date();
				
               var canvas2=document.getElementById("myCanvas");
                var img2= canvas2.toDataURL("image/png");
              
               var id=makeid(5);
             
                form_data.append('file', img2);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',id+".png");
               
                $.ajax({
                    method: 'post',
                    url: 'php/upload_base64.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                      
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=0;
							attachment.name=id+".png";
							attachment.mime_type="image/png";
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+id+".png";
                            temp.lastModification=d.getTime();
                            if(temp.attachmentsList.length>0){
                              
                                //first delete the old file
                     var form_data = new FormData();                  
                form_data.append('file', temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, ''));
                form_data.append('uid',firebase.auth().currentUser.uid);
                     $.ajax({
                      url: "php/delete.php",
                        method: "POST",
                          data: form_data,
                           contentType: false,
                           processData: false,
                            success: function (result) {
                           
                         }
                  });
                            }
                            if(temp.creation==0){
                                 var d = new Date();
                                 temp.creation=d.getTime();
                               	temp.title=$('#text_title_field').val();
	                           
                               //check if the note is checklist
                                if($("#add-todo").is(":visible")){
                                     var i=0;
	                                  var saveString=""; 
	                               
                                     $('#todo-list').find('div').each(function() { 
    
                                          var id = $(this).attr('id');
                                              if(id!="add-todo"&&id!="text_title_wrapper"){	 
                                        	 if($("#"+i).attr("checked")=="checked"||$('#'+i).prop('checked')){
	                                         saveString+="[x] ";
	                                        } else{
	                                        saveString+="[ ] ";
	                                        }	 
	                                        saveString+=$("#label"+i).text().trim();
	                                        saveString+="\n";
                                            i++;
	 }
    
});
  saveString=saveString.replace(/\n$/, "");
  current_note.content=saveString;
                                }else{
                                     temp.content=$('#text_content_field').val();
                                }
                            }
                            temp.attachmentsList[0]=attachment;
                          	var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              
                 loadDataFromFirebase(current_mode);
                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
                

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
});
$('#cameraModal').on('hidden.bs.modal', function () {
  
})
 
  }
  function downloadFile(filePath) {
  var link = document.createElement('a');
  link.href = filePath;
  link.download = filePath.substr(filePath.lastIndexOf('/') + 1);
  link.click();
}

  function showProgress(){
       $("#progressBar").css("visibility", "visible");
  }
  function hideProgress(){
      $("#progressBar").css("visibility", "hidden");
  }
   function loadNote(id,e,t){
    
	 $(t).siblings('.card').removeClass('active');
        $(t).addClass('active');
  
		if(!initNote(all_items,id))
		initNote(trashed_items,id);
		
		
    
  }
  
  function saveNote(){
   var ref = firebase.database().ref(); 
   if(current_note=="undefined"){
    var note = new NoteObject();
	var d = new Date();
    var n = d.getTime();
	note.creation=n;
	note.lastModification=n;
	note.title=$('#text_title_field').val();
	note.content=$('#text_content_field').val();
	ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(note.creation).set(JSON.stringify(note)).then(function(snapshot) {
              

                showSnackbar("הרשימה עודכנה בהצלחה");
               loadDataFromFirebase(current_mode);

            }, function(error) {
                showSnackbar(error);
            });
   } else{  
   if(!current_note.checklist){
	    current_note.title=$('#text_title_field').val();
   current_note.content=$('#text_content_field').val();
   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(current_note.creation).set(JSON.stringify(current_note)).then(function(snapshot) {
              
  loadDataFromFirebase(current_mode);
                showSnackbar("הרשימה עודכנה בהצלחה");
               

            }, function(error) {
                showSnackbar(error);
            });
   }else{
	   var i=0;
	  var saveString=""; 
	    current_note.title=$('#text_title_field').val();
    $('#todo-list').find('div').each(function() { 
    
     var id = $(this).attr('id');
	 if(id!="add-todo"&&id!="text_title_wrapper"){	 
	 
	 
	 if($("#"+i).attr("checked")=="checked"||$('#'+i).prop('checked')){
	 saveString+="[x] ";
	 }else{
	 saveString+="[ ] ";
	 }	 
	 saveString+=$("#label"+i).text().trim();
	 saveString+="\n";
     i++;
	 }
    
});
  saveString=saveString.replace(/\n$/, "");
  current_note.content=saveString;
  console.log(saveString);
  ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(current_note.creation).set(JSON.stringify(current_note)).then(function(snapshot) {
              

                showSnackbar("הרשימה עודכנה בהצלחה");
               

            }, function(error) {
                showSnackbar(error);
            });
   } 
   }
  }
  function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}

  function takePic(temp){
  
 $('#cameraModal').modal('show');
 var video = document.getElementById('video');
var strm;
// Get access to the camera!
if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    // Not adding `{ audio: true }` since we only want video now
    navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
        //video.src = window.URL.createObjectURL(stream);
        strm=stream;
		video.srcObject = stream;
        video.play();
    });
	// Elements for taking the snapshot
var canvas = document.getElementById('canvas');
var context = canvas.getContext('2d');
var video2 = document.getElementById('video');

// Trigger photo take
document.getElementById("snap").addEventListener("click", function() {
	context.drawImage(video2, 0, 0,470, 350);
});

$('#camera_modal_confirm').unbind().on('click', function(evt) {
  
   //save
                    var form_data = new FormData();                  
                var d = new Date();
				
              var canvas = document.getElementById('canvas');
                var img= canvas.toDataURL("image/png");
              
              var id=makeid(5);
             
                form_data.append('file', img);
                form_data.append('uid',firebase.auth().currentUser.uid);
                form_data.append('name',id+".png");
               
                $.ajax({
                    method: 'post',
                    url: 'php/upload_base64.php',
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success:function(response) {
                      
                        if(response == 'success') {
                            var attachment=new Attachment();
                            var d = new Date();
							attachment.id=d.getTime();
							attachment.length=0;
							attachment.name=id+".png";
							attachment.mime_type="image/png";
							attachment.uriPath="file:///storage/emulated/0/Android/data/org.ultimatetoolsil.mike.note/files/"+id+".png";
                            temp.lastModification=d.getTime();
                            if(temp.attachmentsList.length>0){
                              
                                //first delete the old file
                     var form_data = new FormData();                  
                form_data.append('file', temp.attachmentsList[0].uriPath.replace(/^.*[\\\/]/, ''));
                form_data.append('uid',firebase.auth().currentUser.uid);
                     $.ajax({
                      url: "php/delete.php",
                        method: "POST",
                          data: form_data,
                           contentType: false,
                           processData: false,
                            success: function (result) {
                           
                         }
                  });
                            }
                            if(temp.creation==0){
                                 var d = new Date();
                                 temp.creation=d.getTime();
                               	temp.title=$('#text_title_field').val();
	                           
                               //check if the note is checklist
                                if($("#add-todo").is(":visible")){
                                     var i=0;
	                                  var saveString=""; 
	                               
                                     $('#todo-list').find('div').each(function() { 
    
                                          var id = $(this).attr('id');
                                              if(id!="add-todo"&&id!="text_title_wrapper"){	 
                                        	 if($("#"+i).attr("checked")=="checked"||$('#'+i).prop('checked')){
	                                         saveString+="[x] ";
	                                        } else{
	                                        saveString+="[ ] ";
	                                        }	 
	                                        saveString+=$("#label"+i).text().trim();
	                                        saveString+="\n";
                                            i++;
	 }
    
});
  saveString=saveString.replace(/\n$/, "");
  current_note.content=saveString;
                                }else{
                                     temp.content=$('#text_content_field').val();
                                }
                            }
                            temp.attachmentsList[0]=attachment;
                          	var ref = firebase.database().ref(); 
						   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(temp.creation).set(JSON.stringify(temp)).then(function(snapshot) {
              
                 loadDataFromFirebase(current_mode);
                 showSnackbar('הקובץ הועלה בהצלחה');
                 hideProgress();
                

            }, function(error) {
                showSnackbar(error);
            });
						  
                           
                        } else if(response == 'fail') {
                             showSnackbar('Invalid file type.');
                           hideProgress();  
                        } else {
                           showSnackbar('Something went wrong. Please try again.');
                           hideProgress();
                        }
 
                        
                    }
                });
});
$('#cameraModal').on('hidden.bs.modal', function () {
   strm.getTracks().forEach(track => track.stop())
})
 }else{
  showSnackbar("הדפדפן או המחשב אינו תומך במצלמה"); 
 }
 }
  
function gotMedia(mediaStream) {
  const mediaStreamTrack = mediaStream.getVideoTracks()[0];
  const imageCapture = new ImageCapture(mediaStreamTrack);
  console.log(imageCapture);
}
  
   function loadDataFromFirebase(mode){

	  current_mode=mode;
	 all_items=[];
     trashed_items=[];	
	 uncategorized_items=[];
	 archived_items=[];
	 reminders_items=[];
  var ref = firebase.database().ref(); 
   ref.child('users').child(firebase.auth().currentUser.uid).child("v2").child("notes").once("value", function(snapshot) {
      if(snapshot){ 
    snapshot.forEach(function(child) {
	var note = JSON.parse(child.val());
    //append data to list  
	console.log(note);
	if(note.trashed&&!trashed_items.includes(note)){
	 trashed_items.push(note);
	}
	if(note.archived&&!note.trashed&&!archived_items.includes(note)){
	 archived_items.push(note);
	}
	
	if(typeof note.alarm != "undefined"&&!reminders_items.includes(note)){
		console.log(note.alarm);
	reminders_items.push(note);
	}
	if( typeof note.baseCategory=="undefined"&&!uncategorized_items.includes(note)){
	uncategorized_items.push(note);
	}
	if((!note.archived&&!note.trashed)&&!all_items.includes(note))
	all_items.push(note);
  });
  initList(mode);
  hideProgress();
  }else{
       hideProgress();
       showSnackbar("לא נמצאו רשימות בחשבונך");
  }
});
 
   
 

}
function showFile(){
 $('#file').css("visibility","visible");
$('#upload').css("visibility","visible");
    
}
function initCheckCommands(){
// add items
$('#add-todo').click(function(){
  var lastSibling = $('#todo-list > div:last > input').attr("id");
 
 var newId = Number(lastSibling)+1;
      console.log(newId);
  $(this).before('<div <span class="editing todo-wrap"><input type="checkbox" id="'+newId+'" /><label for="'+newId+'" class="todo" id="label'+newId+'" ><i class="fa fa-check"></i><input type="text" class="input-todo" id="input-todo'+newId+'"/></label></div> </div>');
  $('#input-todo'+newId+'').parent().parent().animate({
    height:"36px"
  },200)
  $('#input-todo'+newId+'').focus();
  
	$('#input-todo'+newId+'').enterKey(function(){
    $(this).trigger('enterEvent');
	
  })
  
  $('#input-todo'+newId+'').on('blur enterEvent',function(){
    var todoTitle = $('#input-todo'+newId+'').val();
    var todoTitleLength = todoTitle.length;
    if (todoTitleLength > 0) {
      $(this).before(todoTitle);
      $(this).parent().parent().removeClass('editing');
      $(this).parent().after('<span class="delete-item" title="remove"><i class="fa fa-times-circle"></i></span>');
      $(this).remove();
      $('.delete-item').click(function(){
        var parentItem = $(this).parent();
        parentItem.animate({
          left:"-30%",
          height:0,
          opacity:0
        },200);
        setTimeout(function(){ $(parentItem).remove(); }, 1000);
      });
    }
    else {
      $('.editing').animate({
        height:'0px'
      },200);
      setTimeout(function(){
        $('.editing').remove()
      },400)
    }
  })

});

// remove items 

$('.delete-item').click(function(){
  var parentItem = $(this).parent();
  parentItem.animate({
    left:"-30%",
    height:0,
    opacity:0
  },200);
  setTimeout(function(){ $(parentItem).remove(); }, 1000);
});

// Enter Key detect

$.fn.enterKey = function (fnc) {
    return this.each(function () {
        $(this).keypress(function (ev) {
            var keycode = (ev.keyCode ? ev.keyCode : ev.which);
            if (keycode == '13') {
                fnc.call(this, ev);
            }
        })
    })
}
}

 function animFields(){
 $('#text_title_wrapper').on({
  mouseenter: function(){
      enableFocus(1);
    
  },
  mouseleave: function(){
     
      disableFocus(1);
    
  }
       });
        $('#text_content_wrapper').on({
  mouseenter: function(){
   enableFocus(2);
  },
  mouseleave: function(){
    
     disableFocus(2);
    
  }
});
 }
function reloadStylesheets() {
    var queryString = '?reload=' + new Date().getTime();
    $('link[rel="stylesheet"]').each(function () {
        this.href = this.href.replace(/\?.*|$/, queryString);
    });
}
var globalColor="#536dfe";
function addCategory(){
  var st = tmpl("actions_categorie_add");
  $('#c_body').html("");  
  $('#c_body').append(st);
   var st = tmpl("actions_categorie_add_footer");
  $('#c_footer').html("");  
  $('#c_footer').append(st);
  
  var picker = document.getElementById('picker') // get the color picker element
  function colorChanged (event) {
    var color = event.detail[0] // get the color
    globalColor=color;
    //picker.value = color // set the value of the picker to the selected color
	$('#c_label').css("background-color",color);
  }
  picker.addEventListener('change', colorChanged) // add the event to the picker element
 
  
 
}

function hexToRgb(hex) {
    var bigint = parseInt(hex, 16);
    var r = (bigint >> 16) & 255;
    var g = (bigint >> 8) & 255;
    var b = bigint & 255;

    return r + "," + g + "," + b;
}
function hexToDec(hex) {
    return hex.toLowerCase().split('').reduce( (result, ch) =>
        result * 16 + '0123456789abcdefgh'.indexOf(ch), 0);
}
function saveNewCategory(){
 	var category = new Category();
	var clr="FF";
	clr+=globalColor.replace("#","");
	category.color=''+~~parseInt(clr,16);
	
	category.count=1;
	category.name=$('#input_c_name').val();
	var d = new Date();
    category.id = d.getTime();
	 var ref = firebase.database().ref(); 
	 console.log(category);
	ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").child(category.id).set(category).then(function(snapshot) {
           
             if(typeof current_note!="undefined"){
	 current_note.baseCategory=category;
	 ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(current_note.creation).set(JSON.stringify(current_note)).then(function(snapshot) {
                $("#categorieModal").modal('hide');
                showSnackbar("נשמר בהצלחה"); 

            }, function(error) {
                showSnackbar(error);
            });
	}else{
	 var note = new NoteObject();
	var d = new Date();
    var n = d.getTime();
	note.creation=n;
	note.lastModification=n;
	note.title=$('#text_title_field').val();
	note.content=$('#text_content_field').val();
	ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(note.creation).set(JSON.stringify(note)).then(function(snapshot) {
                showSnackbar("הרשימה עודכנה בהצלחה");

            }, function(error) {
                showSnackbar(error);
            });
	}		

            }, function(error) {
                showSnackbar(error);
            });
	

  
	
}
function addExistingCategory(id){
	 var ref = firebase.database().ref(); 
		ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").child(id).once("value", function(snapshot) {
       if(snapshot){
		var category=snapshot.val();
		category.count+=1;
		  ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").child(id).set(category).then(function(snapshot) {
              if(typeof current_note!="undefined"){  
				current_note.baseCategory=category;
			   ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(current_note.creation).set(category).then(function(snapshot) {
              showSnackbar("הרשימה עודכנה בהצלחה");
										
                     }, function(error) {
                        showSnackbar(error);
                        });
			  }else{
			  //save new note
			  var note = new NoteObject();
			  var d = new Date();
               var n = d.getTime();
	           note.creation=n;
	           note.lastModification=n;
	            note.title=$('#text_title_field').val();
	            note.content=$('#text_content_field').val();
				note.baseCategory=category;
				ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(note.creation).set(JSON.stringify(note)).then(function(snapshot) {
              showSnackbar("הרשימה עודכנה בהצלחה");
										
                     }, function(error) {
                        showSnackbar(error);
                        });
			  
			  }
            }, function(error) {
                showSnackbar(error);
            });
	   }
	 
});
}	
function categorize(){
$('#categorieModal').modal('show');
$('#categorieModal').on('hidden.bs.modal', function () {
    $("#c_footer").html("");
	 $("#c_body").html("");
})
 var ref = firebase.database().ref(); 
		ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").once("value", function(snapshot) {
       if(snapshot){
		 $('#c_body').html("");
		   var st = tmpl("actions_categorie_add_existsing_footer");
                $("#c_footer").html("");
				$('#c_footer').append(st);
	   snapshot.forEach(function(child) {
	  var categorie = child.val();
    //append data to list  
	 var data = {
                    title: categorie.name,
                    id: categorie.id,
					content:categorie.description,
					color:toColor(categorie.color),
					count:categorie.count
               };
                // var data={title:album.title,id:i};

                //console.log(JSON.stringify(x, null, 2));
                var st = tmpl("nav_categorie_template2", data);
                $('#c_body').append(st);
                	$("#categorie"+categorie.id).on('rightclick', function(e) {
                	     e.preventDefault();
  var top = e.pageY - 10;
  var left = e.pageX - 90;
  $("#context-menu").css({
    display: "block",
    top: top,
    left: left
  }).addClass("show");
  return false; //blocks default Webbrowser right click menu
}).on("click", function() {
  $("#context-menu").removeClass("show").hide();

});

$("#context-menu a").on("click", function() {
  $(this).parent().removeClass("show").hide();
});
                
				
				
				
	
  });
  
   $('#btn_category_add').prop('disabled', false);
	   }
});

}
function removeCategory(){
 if(typeof current_note!="undefined"){
	  var c_id=current_note.baseCategory.id;
	 var ref = firebase.database().ref(); 
		ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").child(c_id).once("value", function(snapshot) {
       if(snapshot){
		var category= snapshot.val();
		if(category.count>0)category.count-=1;
		ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("categories").child(c_id).set(category).then(function(snapshot) {
             
         delete current_note.baseCategory;
	 ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(current_note.id).set(JSON.stringify(current_note)).then(function(snapshot) {
                showSnackbar("קטגוריה הוסרה"); 

            }, function(error) {
                showSnackbar(error);
            });
            }, function(error) {
                showSnackbar(error);
            });
	   }
	   }, function(error) {
                showSnackbar(error);
            });
	   

 }else{
  showSnackbar("לא ניתן להסיר קטגוריה");
 }
}
function archiveNote(id,e){

   if (!e) var e = window.event;
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
  var ref = firebase.database().ref(); 
 
 ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(id).once("value", function(snapshot) {
  
	var note = JSON.parse(snapshot.val());
    //append data to list  
	note.archived=true;
    ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(id).set(JSON.stringify(note)).then(function(snapshot) {
              

                showSnackbar("הועבר לארכיון");
                $('#modalConfirmDelete').modal('hide');
				loadDataFromFirebase(current_mode);

            }, function(error) {
                showSnackbar(error);
            });
 });
			
    
}
function trashNote(id,e){
   
   if (!e) var e = window.event;
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
  var ref = firebase.database().ref(); 
 
 ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(id).once("value", function(snapshot) {
  
	var note = JSON.parse(snapshot.val());
    //append data to list  
	if(note.trashed){
	//permanent deleteion
	$('#modalConfirmDelete').modal('show');
	$("#d_confirm").on("click", function(e) {
    e.preventDefault();
    ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(id).remove().then(function(snapshot) {
              

                showSnackbar("נמחק לצמיתות");
                $('#modalConfirmDelete').modal('hide');
			    //loadDataFromFirebase(current_mode);
			    for(var i=0;i<trashed_items.length;i++){
			        if(trashed_items[i].creation==id){
			          
			            trashed_items.splice(i,1);
			            initList(current_mode);
			        }
			    }
			    

            }, function(error) {
                showSnackbar(error);
            });
    
});
$("#d_cancel").on("click", function(e) {
    e.preventDefault();

   $('#modalConfirmDelete').modal('hide');
});

	}else{
	//trash
	note.trashed=true;
	ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("notes").child(id).set(JSON.stringify(note)).then(function(snapshot) {
              loadDataFromFirebase(current_mode);
                showSnackbar("הועבר לאשפה"); 

            }, function(error) {
                showSnackbar(error);
            });
	}
  
});
if (window.event) {
	window.event.cancelBubble=true;
    }
else {
	if (e.cancelable ) {e.stopPropagation();}
	}
}

 window.onload = function() {
      initApp();
      showProgress();
       $('#text_title_field').keyup(function(){
        var isRTL = this.value.match(rtlChar);
        if(isRTL !== null) {
            this.style.direction = 'rtl';
         }
         else {
            this.style.direction = 'ltr';
         }
       });
         $('#text_content_field').keyup(function(){
        var isRTL = this.value.match(rtlChar);
        if(isRTL !== null) {
            this.style.direction = 'rtl';
         }
         else {
            this.style.direction = 'ltr';
         }
    });
      $("#switch_container").click(function(e){
       e.stopPropagation();
      })


   messaging
   .requestPermission()
   .then(function () {
    // showSnackbar("מעתה תקבל התראות בדפדפן על רשימות שיביקשת אנא הקפד להשאיר את הדפדפן פעיל ברקע")
    
   }).then(function(token) {
       
   
   })
   .catch(function (err) {
   console.log(err);
  
 });
       
	 
	  // add items
$('#add-todo').click(function(){
  var lastSibling = $('#todo-list > .todo-wrap:last-of-type > input').attr('id');
  var newId = Number(lastSibling) + 1;
      
  $(this).before('<span class="editing todo-wrap"><input type="checkbox" id="'+newId+'"/><label for="'+newId+'" class="todo"><i class="fa fa-check"></i><input type="text" class="input-todo" id="input-todo'+newId+'"/></label></div>');
  $('#input-todo'+newId+'').parent().parent().animate({
    height:"36px"
  },200)
  $('#input-todo'+newId+'').focus();
  
	$('#input-todo'+newId+'').enterKey(function(){
    $(this).trigger('enterEvent');
  })
  
  $('#input-todo'+newId+'').on('blur enterEvent',function(){
    var todoTitle = $('#input-todo'+newId+'').val();
    var todoTitleLength = todoTitle.length;
    if (todoTitleLength > 0) {
      $(this).before(todoTitle);
      $(this).parent().parent().removeClass('editing');
      $(this).parent().after('<span class="delete-item" title="remove"><i class="fa fa-times-circle"></i></span>');
      $(this).remove();
      $('.delete-item').click(function(){
        var parentItem = $(this).parent();
        parentItem.animate({
          left:"-30%",
          height:0,
          opacity:0
        },200);
        setTimeout(function(){ $(parentItem).remove(); }, 1000);
      });
    }
    else {
      $('.editing').animate({
        height:'0px'
      },200);
      setTimeout(function(){
        $('.editing').remove()
      },400)
    }
  })

});

// remove items 

$('.delete-item').click(function(){
  var parentItem = $(this).parent();
  parentItem.animate({
    left:"-30%",
    height:0,
    opacity:0
  },200);
  setTimeout(function(){ $(parentItem).remove(); }, 1000);
});

// Enter Key detect

$.fn.enterKey = function (fnc) {
    return this.each(function () {
        $(this).keypress(function (ev) {
            var keycode = (ev.keyCode ? ev.keyCode : ev.which);
            if (keycode == '13') {
                fnc.call(this, ev);
            }
        })
    })
}
    };
	
	function showSnackbar(message) {
  // Get the snackbar DIV
  var x = document.getElementById("snackbar");

  // Add the "show" class to DIV
  x.className = "show";
  x.innerHTML=message;
  // After 3 seconds, remove the show class from DIV
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
function initApp() {
      // Listening for auth state changes.
      // [START authstatelistener]
      firebase.auth().onAuthStateChanged(function(user) {
        // [START_EXCLUDE silent]
  
        // [END_EXCLUDE]
        if (user) { 
          // User is signed in.
          var displayName = user.displayName;
          var emailt = user.email;
            //  var account=document.getElementById("account");
            // account.textContent=emailt;
          $('#email_display').text(emailt);
          $('#disconnect').click( function(){
            firebase.auth().signOut().then(function() {
             $.ajax({
            url:"index.php", //the page containing php script
            type: "post", //request type,
            
           data: {login: "logout", name: displayName, email: emailt},
            success: function(response){
           
            window.location = 'https://ultimatesoft-il.com/notes/index.php';
    
   },
   error: function(xhr, status, error) {
  
}
         });
}, function(error) {
  console.error('Sign Out Error', error);
});
   
          });
          var emailVerified = user.emailVerified;
          var photoURL = user.photoURL;
          var isAnonymous = user.isAnonymous ;
          var uid = user.uid;
          var providerData = user.providerData;
         // alert(email); 
             var ref = firebase.app().database().ref();
             loadDataFromFirebase("all");
             ref.child("users").child(uid).child("v2").child("desktop_notifications").once("value", function(snapshot) {
             if(snapshot.exists()){
                 on=snapshot.val();
                 if(on){$("#id-name--1").prop('checked', true);
                messaging.getToken().then((currentToken) => {
  if (currentToken) {
  	 var ref = firebase.database().ref(); 
  	 ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("FcmTokens").child("1").set(currentToken);

  } else {
    // Show permission request.
    console.log('No Instance ID token available. Request permission to generate one.');
    // Show permission UI.
  
  }
}).catch((err) => {
  console.log('An error occurred while retrieving token. ', err);
 
 
});
  
                 
                 }
                 else if(on)$("#id-name--1").prop('checked', false);
             }else
                  $("#id-name--1").prop('checked', true);
             });     

           $('#id-name--1').change(function(){
   if(this.checked){
     	ref.child('users').child(uid).child("v2").child("desktop_notifications").set(true);
   messaging
   .requestPermission()
   .then(function () {
       messaging.getToken().then((currentToken) => {
  if (currentToken) {
  	 var ref = firebase.database().ref(); 
  	 ref.child('users').child( firebase.auth().currentUser.uid).child("v2").child("FcmTokens").child("1").set(currentToken);

  } else {
    // Show permission request.
    console.log('No Instance ID token available. Request permission to generate one.');
    // Show permission UI.
  
  }
}).catch((err) => {
  console.log('An error occurred while retrieving token. ', err);
 
 
});
  
     showSnackbar("מעתה תקבל התראות בדפדפן על רשימות שיביקשת אנא הקפד להשאיר את הדפדפן פעיל ברקע")
    
   }).then(function(token) {
   
   })
   .catch(function (err) {
  
  
 });
       
   }
   else
      	ref.child('users').child(uid).child("v2").child("desktop_notifications").set(false);

     
});
            // [END_EXCLUDE]
       
       
        } else {
         //window.location.replace("login/index.html");
        
        }
        // [START_EXCLUDE silent]
      
        // [END_EXCLUDE]
      });
      // [END authstatelistener]
   
  
}	

function Category(){
this.id=0;
this.name="";
this.description="";
this.color="";
this.count=0;
}

function NoteObject(){
	
  this. passwordChecked=false;  
  this.title="";
  this. content="";
   this.creation=0;
   this.lastModification=0;
   this. archived=false;
   this.  trashed=false;
  this.  reminderFired=false;
 this. recurrenceRule="";
 
  this.  locked=false;
  this.  checklist=false;
  this.  attachmentsList=[];
 
  this.locked=false;

	
}

function Attachment(){
 this.id=0;
 this.length=0;
 this.mime_type="";
 this.name="";
 this.size=0;
 this.uriPath="";
}